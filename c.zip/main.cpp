#include "fatoracao.h"

using namespace std;

void Menu(){
    system("clear");
    cout << "\nBem vindo ao Fatorador de primos! \n";
    cout << "1- Realizar Fatoração \n";
    cout << "2- Sair \n";
}
int main(){
    Fat * Inicio = NULL, *Fim = NULL, F;
    int op, n, d;
    do{
        Menu();
        cin >> op;
        switch(op){
            case 1:
                cout<<"Insira o numero:";
                cin>>n;

                Fim = F.Fatoracao(Fim, n);
                if(Inicio ==NULL)
                    Inicio = Fim;
                cout<<"Fatoração prima: \n";
                F.Listar(Inicio);
            break;
            case 2:
                cout<<"tchauu";
                break;
                default:
                cout<<"invalido!";
                }
    }while(op != 2);
    return 0;
}